# SuperMarioOdyssey-All-Kingdom-Saves
This consists of saves from all the Super Mario Odyssey Kingdoms.
